package intransix.osm.termite.render.edit;

/**
 *
 * @author sutter
 */
public abstract class EditObject extends EditDrawable {

}

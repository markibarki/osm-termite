/** This package contains classes to hold data in OSM format. */
package intransix.osm.termite.map.data;
package intransix.osm.termite.map.data;

/**
 *
 * @author sutter
 */
	
public class PropertyPair {

	public PropertyPair(String key, String value) {
		this.key = key;
		this.value = value;
	}

	public String key;
	public String value;
}
